import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { PGlite } from '@electric-sql/pglite';
import { serve, placeholders } from '../lib/postgres.mjs';
import { handle } from '../app/server.ts';

test('PostgreSQL adapter preserves quoted question marks',()=>{
  assert.equal(placeholders("SELECT '?' as literal, ? as value, 'it''s ?' as other"),"SELECT '?' as literal, $1 as value, 'it''s ?' as other");
});

test('room API works on a real embedded PostgreSQL engine',async()=>{
  const database = new PGlite();
  const sql = await readFile(new URL('../sql/001-init.sql',import.meta.url),'utf8');
  await database.exec(sql);
  // PGlite has one connection. Its exclusive transaction queue models a pool
  // for this SQL/contract test; actual Vercel connections use PostgreSQL row locks.
  let pending=Promise.resolve();
  async function exclusive(){let release;const previous=pending;pending=new Promise(resolve=>{release=resolve;});await previous;return release;}
  const result=async(sql,params)=>{const response=await database.query(sql,params);return{rows:response.rows};};
  const pool={
    async query(sql,params){const release=await exclusive();try{return await result(sql,params);}finally{release();}},
    async connect(){const release=await exclusive();return{query:result,release};},
  };
  const server=createServer(async(req,res)=>{
    try {
      const chunks=[];for await(const chunk of req)chunks.push(chunk);
      const body=Buffer.concat(chunks);
      const request=new Request(`http://127.0.0.1:${server.address().port}${req.url}`,{method:req.method,headers:req.headers,...(req.method==='GET'?{}:{body})});
      const response=await serve(request,handle,pool);
      res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
    } catch(error){res.writeHead(500);res.end(JSON.stringify({error:error.message}));}
  });
  server.listen(0,'127.0.0.1');await once(server,'listening');
  const origin=`http://127.0.0.1:${server.address().port}`;
  try {
    // Exercise the same independent-session contract used for the Cloudflare build.
    // The HTTP server must stay live, so launch the fixture asynchronously.
    const { spawn } = await import('node:child_process');
    const child=spawn(process.execPath,['--test','--test-isolation=none','tests/rooms.test.mjs'],{env:{...process.env,KRUG_TEST_ORIGIN:origin},stdio:['ignore','pipe','pipe']});
    let output='';child.stdout.on('data',chunk=>{output+=chunk;});child.stderr.on('data',chunk=>{output+=chunk;});
    const [code]=await once(child,'close');assert.equal(code,0,output);
    const noStorage=await serve(new Request(origin+'/api/create',{method:'POST',headers:{'content-type':'application/json'},body:'{}'}),handle,null);
    assert.equal(noStorage.status,503);assert.match((await noStorage.json()).error,/DATABASE_URL/);
    const apiConfig=await fetch(origin+'/api/config');assert.equal(apiConfig.status,200);assert.equal((await apiConfig.json()).maxMembers,4);
  } finally {
    server.close();await once(server,'close');await database.close();
  }
});
