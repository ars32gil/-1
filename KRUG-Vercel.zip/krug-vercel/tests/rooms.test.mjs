import test from 'node:test';
import assert from 'node:assert/strict';

const origin=process.env.KRUG_TEST_ORIGIN || 'http://127.0.0.1:5173';
const id=()=>crypto.randomUUID().replaceAll('-','');
async function call(action,body,session){
  const response=await fetch(origin+'/api/'+action,{method:'POST',headers:{'content-type':'application/json','x-session':session?.token||''},body:JSON.stringify({...session,...body})});
  return {status:response.status,data:await response.json()};
}
async function sync(session,initial=false,since=0){
  const response=await fetch(`${origin}/api/sync?room=${session.room}&client=${session.client}&initial=${initial?1:0}&since=${since}`,{headers:{'x-session':session.token}});
  assert.equal(response.status,200);return response.json();
}

test('two independent participants share objects, chat, cursors and persisted images',async()=>{
  const {data:{room}}=await call('create',{title:'Проверка совместной работы'});
  const a={room,...(await call('join',{room,name:'Первый'})).data};
  const b={room,...(await call('join',{room,name:'Второй'})).data};
  assert.notEqual(a.client,b.client);
  let snapshot=await sync(b,true);assert.equal(snapshot.people.length,2);
  const object={id:id(),type:'note',x:120,y:80,w:220,h:160,rotation:0,color:'#e1ead7',text:'Общая идея'};
  assert.equal((await call('object',{object},a)).status,200);
  let changes=await sync(b,false,snapshot.since);assert.equal(changes.events.find(e=>e.type==='object').data.text,'Общая идея');
  assert.equal((await call('object',{object:{...object,text:'Правка второго участника',x:260}},b)).status,200);
  snapshot=await sync(a,true);assert.equal(snapshot.objects[0].text,'Правка второго участника');assert.equal(snapshot.objects[0].x,260);
  await call('chat',{text:'Привет, команда!'},b);
  snapshot=await sync(a,true);assert.equal(snapshot.messages[0].data.text,'Привет, команда!');
  await call('presence',{mic:false,camera:false,hand:true,cursor:{x:123,y:456}},b);
  snapshot=await sync(a,true);assert.deepEqual(snapshot.people.find(p=>p.id===b.client).state.cursor,{x:123,y:456});
  const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aNUYAAAAASUVORK5CYII=','base64');
  const upload=await fetch(`${origin}/api/upload?room=${room}&client=${a.client}`,{method:'POST',headers:{'x-session':a.token,'content-type':'image/png'},body:png});assert.equal(upload.status,200);
  const image=await upload.json();const fetched=await fetch(origin+image.url);assert.equal(fetched.status,200);assert.equal(fetched.headers.get('content-type'),'image/png');assert.equal((await fetched.arrayBuffer()).byteLength,png.length);
  await call('object',{object:{id:id(),type:'image',x:100,y:100,w:100,h:100,color:'#334b37',url:image.url}},a);
  snapshot=await sync(b,true);assert(snapshot.objects.some(o=>o.url===image.url));
  assert.equal((await call('object',{object}, {...a,token:'wrong-token'})).status,401);
  assert.equal((await call('object',{object:{...object,x:Infinity,url:'javascript:alert(1)',type:'image'}},a)).status,400);
  await call('delete',{id:object.id},b);snapshot=await sync(a,true);assert(!snapshot.objects.some(o=>o.id===object.id));
  await call('leave',{},b);snapshot=await sync(a,true);assert.equal(snapshot.people.length,1);
  const returned=await call('join',{room,name:'Второй',client:b.client,token:b.token});assert.equal(returned.data.client,b.client);
  snapshot=await sync(b,true);assert(snapshot.objects.some(o=>o.url===image.url));
  await call('leave',{},a);await call('leave',{},b);
});

test('simultaneous joins respect room capacity and signaling stays addressed',async()=>{
  const {data:{room}}=await call('create',{title:'Проверка вместимости'});
  const responses=await Promise.all(Array.from({length:8},(_,i)=>call('join',{room,name:'Участник '+i})));
  assert.equal(responses.filter(r=>r.status===200).length,4);assert.equal(responses.filter(r=>r.status===409).length,4);
  const members=responses.filter(r=>r.status===200).map(r=>({room,...r.data}));
  const [a,b,c]=members;const initial=await sync(b,true);
  await call('signal',{target:b.client,signal:{type:'offer',description:{type:'offer',sdp:'test-signal'}}},a);
  const addressed=await sync(b,false,initial.since);assert.equal(addressed.events.find(e=>e.type==='signal').data.description.sdp,'test-signal');
  const other=await sync(c,false,initial.since);assert(!other.events.some(e=>e.type==='signal'));
  await Promise.all(members.map(m=>call('leave',{},m)));
});
