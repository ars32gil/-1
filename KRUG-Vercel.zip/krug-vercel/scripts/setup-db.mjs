import nextEnv from '@next/env';
import pg from 'pg';
import { readFile } from 'node:fs/promises';
nextEnv.loadEnvConfig(process.cwd());

if (!process.env.DATABASE_URL) {
  if (process.argv.includes('--if-configured')) {
    console.log('DATABASE_URL is not set. Building the trial board; connect PostgreSQL and redeploy to enable meetings.');
    process.exit(0);
  }
  console.error('Set DATABASE_URL in .env.local (or Vercel Environment Variables) first.');
  process.exit(1);
}
const client = new pg.Client({connectionString:process.env.DATABASE_URL,connectionTimeoutMillis:15000});
try {
  await client.connect();
  await client.query('BEGIN');
  await client.query('SELECT pg_advisory_xact_lock(731194280)');
  const schema = await readFile(new URL('../sql/001-init.sql',import.meta.url),'utf8');
  await client.query(schema);
  await client.query('COMMIT');
  console.log('PostgreSQL schema is ready.');
} catch (error) {
  await client.query('ROLLBACK').catch(()=>{});
  console.error('Database setup failed. Verify DATABASE_URL, connectivity and CREATE TABLE permissions. Error code:',error.code || 'unknown');
  process.exitCode=1;
} finally { await client.end(); }
