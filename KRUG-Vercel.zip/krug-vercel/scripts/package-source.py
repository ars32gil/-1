"""Package only deployable source, instructions and tests; never keys or caches."""
from pathlib import Path
import sys
import zipfile

root = Path(__file__).resolve().parents[1]
target = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root.parent / "KRUG-Vercel.zip"
top_files = ["package.json", "package-lock.json", "next.config.mjs", "next-env.d.ts", "tsconfig.json", "vercel.json", "README.md", ".env.example", ".gitignore"]
folders = ["app", "lib", "public", "scripts", "sql", "tests"]
files = [root / name for name in top_files]
files += [item for name in folders for item in (root / name).rglob("*") if item.is_file() and "__pycache__" not in item.parts]
for item in files:
    if not item.is_file() or item.is_symlink():
        raise SystemExit(f"Missing or unsafe source file: {item.name}")
target.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for item in sorted(files):
        archive.write(item, "krug-vercel/" + item.relative_to(root).as_posix())
with zipfile.ZipFile(target) as archive:
    if archive.testzip() is not None:
        raise SystemExit("Archive integrity check failed")
    names = archive.namelist()
    forbidden = [name for name in names if any(part in name.split("/") for part in ["node_modules", ".next", ".vercel", ".npm-cache", ".git", ".wrangler"]) or Path(name).name in [".env", ".env.local", ".env.production"]]
    if forbidden:
        raise SystemExit("Unexpected runtime data in archive")
print(f"{target}\n{len(files)} files, {target.stat().st_size} bytes")
