import { icon } from './ui';

const escape = (s = '') => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid = () => crypto.randomUUID().replaceAll('-', '');
const clone = o => o ? JSON.parse(JSON.stringify(o)) : null;
const defaults = { color:'#334b37', size:3, rotation:0, w:220, h:160 };
const noteColors = ['#edf0b8','#e1ead7','#e9e1ef','#f1ddce'];
const postcard = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="230" height="176" viewBox="0 0 230 176"><rect width="230" height="176" fill="#ebeade"/><path d="M116 160Q101 120 119 64" fill="none" stroke="#6e8056" stroke-width="3"/><path d="M114 128Q74 103 79 89Q119 88 114 128M113 106Q140 68 158 79Q151 112 113 106" fill="#9da984"/><g fill="#f4b493"><ellipse cx="119" cy="44" rx="13" ry="23"/><ellipse cx="119" cy="44" rx="13" ry="23" transform="rotate(60 119 64)"/><ellipse cx="119" cy="44" rx="13" ry="23" transform="rotate(120 119 64)"/><ellipse cx="119" cy="44" rx="13" ry="23" transform="rotate(180 119 64)"/><ellipse cx="119" cy="44" rx="13" ry="23" transform="rotate(240 119 64)"/><ellipse cx="119" cy="44" rx="13" ry="23" transform="rotate(300 119 64)"/></g><circle cx="119" cy="64" r="13" fill="#d1a869"/><text x="16" y="160" font-family="sans-serif" font-size="8" fill="#859077" letter-spacing="1.5">A FRESH PERSPECTIVE</text><path d="m193 21 9 9m-9 0 9-9" stroke="#b4baa6" stroke-width="1.2"/></svg>`);

export function start() {
  const root = document.getElementById('krug');
  if (!root || root.dataset.started) return () => {};
  root.dataset.started = 'true';
  const $ = selector => root.querySelector(selector);
  const viewport = $('#viewport'), world = $('#world'), objectLayer = $('#objects'), strokes = $('#strokes'), modal = $('#modal');
  const abort = new AbortController();
  const on = (target, event, fn, opts = {}) => target.addEventListener(event, fn, { ...opts, signal:abort.signal });
  const state = { room:new URL(location.href).searchParams.get('room'), client:null, token:null, name:localStorage.getItem('krug-name') || 'Вы', color:'#56724b', objects:new Map(), people:[], messages:[], since:0, tool:'cursor', selected:null, color:defaults.color, noteColor:0, zoom:1, pan:{x:0,y:0}, gesture:null, cursor:null, mic:false, camera:false, hand:false, screen:null, localStream:new MediaStream(), peers:new Map(), panel:null, started:Date.now(), joined:false, dead:false, failures:0, history:[], redo:[], pending:new Map(), saves:0, iceServers:[{ urls:'stun:stun.l.google.com:19302' }], signals:new Set(), writes:Promise.resolve() };
  const timers = new Set();
  function later(fn,ms) { const t=setTimeout(()=>{timers.delete(t);if(!state.dead)fn();},ms);timers.add(t);return t; }
  let toastTimer, pollTimer, presenceTimer, syncing=false;
  function toast(text) { const el=$('#toast');el.textContent=text;el.hidden=false;clearTimeout(toastTimer);toastTimer=later(()=>{el.hidden=true;},4300); }
  async function api(action, body, query = '') {
    const opts = { headers:{'x-session':state.token || ''}, signal:AbortSignal.timeout(15000) };
    if(body !== undefined){ opts.method='POST';opts.headers['content-type']='application/json';opts.body=JSON.stringify({room:state.room,client:state.client,...body}); }
    const q=body===undefined && state.room ? `?room=${state.room}&client=${state.client || ''}${query}` : '';
    const res=await fetch(`/api/${action}${q}`,opts);
    let data;try {data=await res.json();}catch{throw new Error('Сервер недоступен. Попробуйте ещё раз.');}
    if(!res.ok)throw new Error(data.error || 'Не удалось выполнить действие');
    return data;
  }
  function showModal(content) { $('#modal-content').innerHTML=content;if(!modal.open)modal.showModal();later(()=>modal.querySelector('input,textarea,button.primary-button')?.focus(),60); }
  const symbol=name=>`<div class="modal-symbol">${icon(name)}</div>`;
  function roomDialog(join=false) {
    showModal(`${symbol('people')}<h2>${join?'Войдите в свой круг':'Соберите свой круг'}</h2><p>${join?'Встреча, разговор и общая доска — всё в одном месте. Представьтесь, чтобы коллеги узнали вас.':'Создайте встречу и пригласите коллег по ссылке. До четырёх участников, одна общая доска и сколько угодно идей.'}</p><form id="room-form"><label for="name-input">Ваше имя</label><input id="name-input" name="name" value="${escape(state.name==='Вы'?'':state.name)}" placeholder="Как к вам обращаться?" maxlength="40" required autocomplete="given-name"/>${join?'':'<label for="title-input">Название встречи</label><input id="title-input" name="title" value="Дизайн-сессия" maxlength="80" required/>'}<div id="form-error" class="error-line" role="alert"></div><button class="primary-button" type="submit">${join?'Присоединиться':'Создать встречу'} ${icon('arrow')}</button></form><p class="small-print">Камеру и микрофон можно включить после входа.<br>Доска доступна каждому участнику.</p>`);
    on($('#room-form'),'submit',async e=>{
      e.preventDefault();const btn=e.target.querySelector('button');btn.disabled=true;btn.textContent='Подключаемся…';$('#form-error').textContent='';
      try {
        const name=$('#name-input').value.trim();if(!name)throw new Error('Укажите ваше имя');state.name=name;localStorage.setItem('krug-name',name);
        let fresh=false;
        if(!join) { const created=await api('create',{title:$('#title-input').value});state.room=created.room;sessionStorage.setItem(`krug-owner-${state.room}`,created.owner);fresh=true; }
        const saved=JSON.parse(sessionStorage.getItem(`krug-session-${state.room}`)||'{}');
        const joined=await api('join',{name,client:saved.client,token:saved.token,owner:sessionStorage.getItem(`krug-owner-${state.room}`)});
        state.client=joined.client;state.token=joined.token;state.color=joined.color;state.joined=true;state.started=Date.now();
        sessionStorage.setItem(`krug-session-${state.room}`,JSON.stringify({client:state.client,token:state.token}));
        const next=new URL(location.href);next.searchParams.set('room',state.room);history.replaceState(null,'',next);
        state.objects.clear();state.history=[];state.redo=[];state.messages=[];state.since=0;state.selected=null;root.classList.add('in-call');$('#board-intro').hidden=true;$('#demo-label')?.remove();
        $('#room-title').childNodes[0].textContent=joined.title+' ';$('#room-status').textContent='В эфире';$('#board-hint').textContent='Одна доска. Много точек зрения.';$('#local-name').innerHTML=`${escape(name)} <small>это вы</small>`;$('.my-avatar').textContent=name[0].toUpperCase();$('.person-initial').textContent=name[0].toUpperCase();
        modal.close();renderBoard();setSaveStatus();
        const config=await api('config');state.iceServers=config.iceServers;
        await sync(true);schedulePoll();schedulePresence();
        if(fresh) { await seedRoom(); inviteDialog(); } else toast('Вы в круге. Добро пожаловать!');
      } catch(err) { const el=$('#form-error');if(el)el.textContent=err.message;else toast(err.message); }
      finally {btn.disabled=false;btn.innerHTML=(join?'Присоединиться':'Создать встречу')+' '+icon('arrow');}
    });
  }
  function inviteDialog() {
    if(!state.joined){roomDialog(!!state.room);return;}
    showModal(`${symbol('link')}<h2>Хорошие идеи<br>любят компанию.</h2><p>Отправьте ссылку коллегам — они смогут присоединиться к встрече и рисовать вместе с вами.</p><label for="invite-url">Ссылка на вашу встречу</label><div class="copy-field"><input readonly id="invite-url" value="${escape(location.href)}"/><button data-action="copy">Копировать</button></div><p class="small-print">В комнате может быть до 4 участников.<br>Каждый, у кого есть ссылка комнаты, может присоединиться.</p><button class="primary-button" data-action="close-modal">Вернуться к идеям ${icon('arrow')}</button>`);
  }
  function help() {
    showModal(`${symbol('board')}<h2>Меньше барьеров.<br>Больше идей.</h2><p>Выберите инструмент слева и нажмите на доску. Всё, что вы добавляете во встрече, видят остальные.</p>${[['cursor','Выбрать и переместить объект','V'],['pen','Рисовать от руки','P'],['text','Добавить текст','T'],['note','Добавить стикер','N'],['image','Загрузить изображение','I'],['hand','Перемещаться по доске','H']].map(([i,t,k])=>`<div class="help-row">${icon(i)} ${t}<kbd>${k}</kbd></div>`).join('')}<p class="small-print">Колесо мыши — перемещение · Ctrl + колесо — масштаб<br>Двойной клик — изменить текст · Delete — удалить<br>Ctrl + Z — отменить · Ctrl + Shift + Z — повторить</p><button class="primary-button" data-action="close-modal">Понятно, давайте творить</button>`);
  }
  function transform(){world.style.transform=`translate(${state.pan.x}px,${state.pan.y}px) scale(${state.zoom})`;$('#zoom-value').textContent=Math.round(state.zoom*100)+'%';renderCursors();}
  function toWorld(e){const r=viewport.getBoundingClientRect();return{x:(e.clientX-r.left-state.pan.x)/state.zoom,y:(e.clientY-r.top-state.pan.y)/state.zoom};}
  function renderBoard(){
    const fragment=document.createDocumentFragment();
    const svg=[];
    for(const o of state.objects.values()){
      if(o.type==='stroke'){svg.push(`<polyline data-id="${o.id}" points="${(o.points||[]).map(p=>p.join(',')).join(' ')}" fill="none" stroke="${escape(o.color)}" stroke-width="${o.size}" stroke-linecap="round" stroke-linejoin="round"/>`);continue;}
      const el=document.createElement('div');el.className=`board-object ${o.type}${state.selected===o.id?' selected':''}`;el.dataset.id=o.id;el.style.cssText=`left:${o.x}px;top:${o.y}px;width:${o.w}px;height:${o.h}px;transform:rotate(${o.rotation||0}deg);--object-color:${o.color};`;
      if(o.type==='note'){el.style.background=o.color;el.innerHTML=`<span>${escape(o.text)}</span><small class="note-author">${escape(state.people.find(p=>p.id===o.author)?.name|| (state.joined?'Идея для команды':'Ваша идея'))}</small>`;}
      if(o.type==='text'){el.textContent=o.text;el.style.color=o.color;el.style.fontSize=(o.size||18)+'px';}
      if(o.type==='image')el.innerHTML=`<img src="${escape(o.url)}" alt="Изображение на общей доске" draggable="false"/>`;
      fragment.appendChild(el);
    }
    objectLayer.replaceChildren(fragment);strokes.innerHTML=svg.join('');
    const selected=state.objects.get(state.selected);$('#selection-toolbar').hidden=!selected;$('#selection-toolbar [data-action="edit-object"]').hidden=!selected||!['note','text'].includes(selected.type);
    $('[data-action="undo"]').disabled=state.history.length===0;$('[data-action="redo"]').disabled=state.redo.length===0;
    transform();
  }
  function demoSeed(){
    let saved;try{saved=JSON.parse(localStorage.getItem('krug-demo')||'null');}catch{}
    if(saved?.length){for(const o of saved)state.objects.set(o.id,o);renderBoard();return;}
    const w=viewport.clientWidth, right=Math.max(420,w*.5), lower= Math.min(235,viewport.clientHeight-160);
    const samples=[
      {id:'demo-note-one',type:'note',x:right,y:57,w:183,h:164,rotation:-5,color:'#edf0b8',text:'С чего начнём?\n\nС самой смелой\nидеи ✨'},
      {id:'demo-note-two',type:'note',x:right+175,y:lower,w:182,h:145,rotation:4,color:'#e1ead7',text:'А что, если\nпопробовать\nпо-другому?'},
      {id:'demo-image-one',type:'image',x:right+220,y:43,w:192,h:162,rotation:6,url:postcard},
      {id:'demo-text-one',type:'text',x:Math.max(135,right-230),y:lower+60,w:205,h:50,size:14,color:'#9ba689',text:'Ни одна идея\nне лишняя :)',rotation:-5},
      {id:'demo-stroke-one',type:'stroke',color:'#9cae86',size:2,points:[[right-130,lower+30],[right-105,lower+35],[right-77,lower+30],[right-52,lower+12],[right-30,lower-8],[right-7,lower-20],[right+13,lower-20],[right+2,lower-31],[right+13,lower-20],[right+2,lower-10]]},
    ];
    if(w<700){samples.forEach(o=>{if(o.type!=='stroke')o.x+=160;});}
    samples.forEach(o=>state.objects.set(o.id,{...defaults,...o}));renderBoard();
  }
  async function seedRoom(){
    const w=viewport.clientWidth;
    const x=Math.max(100, (w-640)/2);
    const samples=[{type:'text',x,y:45,w:600,h:50,size:28,text:'Большие идеи начинаются с разговора.',color:'#5c704a'}, {type:'note',x,y:130,w:200,h:170,color:noteColors[0],rotation:-3,text:'Что обсудим?\n\nДобавьте сюда\nпервый вопрос.'},{type:'note',x:x+230,y:145,w:200,h:170,color:noteColors[1],rotation:2,text:'Наши идеи\n\nЗдесь можно\nмыслить смело.'},{type:'note',x:x+460,y:125,w:200,h:170,color:noteColors[2],rotation:-2,text:'Следующий шаг\n\nВо что превратим\nнаши идеи?'}];
    for(const o of samples)await save({...defaults,...o,id:uid(),author:state.client},false);
  }
  function setSaveStatus(){const el=$('#save-status');el.innerHTML=icon(state.saves?'more':'check')+' '+(state.saves?'Сохраняем…':state.joined?'Все изменения сохранены':'Сохранено на этом устройстве');}
  function storeDemo(){try{localStorage.setItem('krug-demo',JSON.stringify([...state.objects.values()]));}catch{toast('Память браузера заполнена. Скачайте доску, чтобы сохранить её.');}setSaveStatus();}
  async function save(o,record=true,before=undefined){
    const previous=before===undefined?clone(state.objects.get(o.id)):before;
    if(record){state.history.push({id:o.id,before:previous,after:clone(o)});state.redo=[];}
    state.objects.set(o.id,clone(o));renderBoard();
    if(!state.joined){storeDemo();return;}
    const revision=uid();state.pending.set(o.id,revision);state.saves++;setSaveStatus();
    // Serial writes preserve pointer order and prevent an older move overwriting a newer one.
    const write=state.writes.then(()=>api('object',{object:o}));state.writes=write.catch(()=>{});
    try{await write;}catch(err){toast(err.message);if(state.pending.get(o.id)===revision){if(previous)state.objects.set(o.id,previous);else state.objects.delete(o.id);renderBoard();}}
    finally{if(state.pending.get(o.id)===revision)state.pending.delete(o.id);state.saves--;setSaveStatus();}
  }
  async function remove(id,record=true){
    const before=clone(state.objects.get(id));if(!before)return;
    if(record){state.history.push({id,before,after:null});state.redo=[];}
    state.objects.delete(id);state.selected=null;renderBoard();
    if(!state.joined){storeDemo();return;}
    state.pending.set(id,'delete');state.saves++;setSaveStatus();
    const write=state.writes.then(()=>api('delete',{id}));state.writes=write.catch(()=>{});
    try{await write;}catch(err){state.objects.set(id,before);renderBoard();toast(err.message);}finally{state.pending.delete(id);state.saves--;setSaveStatus();}
  }
  async function undo(redo=false){const source=redo?state.redo:state.history,target=redo?state.history:state.redo;const op=source.pop();if(!op)return;target.push(op);const o=redo?op.after:op.before;if(o)await save(o,false);else await remove(op.id,false);renderBoard();}
  function setTool(tool){
    if(tool==='image'){$('#image-input').click();return;}
    state.tool=tool;root.querySelectorAll('[data-tool]').forEach(el=>{el.classList.toggle('active',el.dataset.tool===tool);el.setAttribute('aria-pressed',String(el.dataset.tool===tool));});
    viewport.className=`board-viewport cursor-${tool}`;$('#colors').hidden=!['pen','shape'].includes(tool);if(tool!=='cursor'){state.selected=null;renderBoard();}
    const hints={cursor:'Перетаскивайте идеи и находите связи',pen:'Рисуйте свободно. Здесь нет неправильных линий.',text:'Нажмите на доску, чтобы добавить текст',note:'Нажмите на доску, чтобы оставить идею',shape:'Потяните, чтобы нарисовать прямоугольник',hand:'Потяните доску, чтобы переместиться'};$('#board-hint').textContent=hints[tool];
  }
  function editText(o,isNew=false){
    showModal(`${symbol(o.type==='note'?'note':'text')}<h2>${isNew?'Добавьте свою мысль':'Дайте идее форму'}</h2><p>${o.type==='note'?'Одна мысль — один стикер. Так проще видеть общую картину.':'Текст увидят все участники встречи.'}</p><form id="object-form"><label for="object-text">${o.type==='note'?'Текст стикера':'Ваш текст'}</label><textarea id="object-text" maxlength="4000" placeholder="А что, если…">${escape(o.text||'')}</textarea>${o.type==='note'?`<label>Цвет стикера</label><div style="display:flex;gap:13px;padding:7px 0">${noteColors.map(c=>`<button type="button" data-note-color="${c}" class="color ${o.color===c?'active':''}" style="--color:${c};width:29px;height:29px" aria-label="Цвет стикера ${c}"></button>`).join('')}</div>`:''}<button type="submit" class="primary-button">${isNew?'Добавить на доску':'Сохранить мысль'} ${icon('arrow')}</button></form>`);
    let color=o.color;
    root.querySelectorAll('[data-note-color]').forEach(btn=>on(btn,'click',()=>{color=btn.dataset.noteColor;root.querySelectorAll('[data-note-color]').forEach(b=>b.classList.toggle('active',b===btn));}));
    on($('#object-form'),'submit',e=>{e.preventDefault();const text=$('#object-text').value.trim();if(!text){$('#object-text').focus();return;}save({...o,text,color});modal.close();state.selected=o.id;setTool('cursor');});
    later(()=>{$('#object-text')?.focus();},100);
  }
  on(viewport,'pointerdown',e=>{
    if(e.target.closest('button,.drawing-tools,.color-toolbar,.selection-toolbar,.board-bottom')||root.classList.contains('view-video')||e.button>1)return;
    if(e.target.closest('.demo-label')){roomDialog(!!state.room);return;}
    const p=toWorld(e);viewport.setPointerCapture(e.pointerId);
    if(state.tool==='hand'||e.button===1||e.altKey){state.gesture={type:'pan',start:{x:e.clientX,y:e.clientY},before:{...state.pan}};return;}
    if(state.tool==='pen'){const o={...defaults,id:uid(),type:'stroke',color:state.color,points:[[p.x,p.y]],author:state.client};state.gesture={type:'stroke',object:o};state.objects.set(o.id,o);renderBoard();return;}
    if(state.tool==='shape'){const o={...defaults,id:uid(),type:'rect',x:p.x,y:p.y,w:1,h:1,color:state.color,author:state.client};state.gesture={type:'shape',start:p,object:o};state.objects.set(o.id,o);renderBoard();return;}
    if(['text','note'].includes(state.tool)){const note=state.tool==='note';const o={...defaults,id:uid(),type:note?'note':'text',x:p.x,y:p.y,w:note?215:320,h:note?175:90,size:note?3:20,color:note?noteColors[(state.noteColor++)%4]:state.color,text:'',author:state.client};editText(o,true);return;}
    const el=e.target.closest('.board-object');if(el){const o=state.objects.get(el.dataset.id);const now=performance.now();if(state.lastClick?.id===o.id&&now-state.lastClick.time<450&&['note','text'].includes(o.type)){state.lastClick=null;state.gesture=null;editText(o);return;}state.lastClick={id:o.id,time:now};state.selected=o.id;const rect=el.getBoundingClientRect();const resize=e.clientX>rect.right-16&&e.clientY>rect.bottom-16;state.gesture={type:resize?'resize':'move',start:p,before:clone(o),object:o};renderBoard();}
    else {
      let found=null;for(const o of [...state.objects.values()].reverse()){if(o.type==='stroke'&&o.points?.some(pt=>Math.hypot(pt[0]-p.x,pt[1]-p.y)<12/state.zoom)){found=o;break;}}
      state.selected=found?.id||null;renderBoard();
    }
  });
  on(viewport,'pointermove',e=>{
    const p=toWorld(e);state.cursor=p;const g=state.gesture;if(!g)return;
    if(g.type==='pan'){state.pan={x:g.before.x+e.clientX-g.start.x,y:g.before.y+e.clientY-g.start.y};transform();return;}
    if(g.type==='stroke'){const pts=g.object.points,last=pts.at(-1);if(pts.length<2900&&Math.hypot(p.x-last[0],p.y-last[1])>1.6/state.zoom){pts.push([p.x,p.y]);renderBoard();}return;}
    if(g.type==='shape'){g.object.x=Math.min(g.start.x,p.x);g.object.y=Math.min(g.start.y,p.y);g.object.w=Math.max(10,Math.abs(p.x-g.start.x));g.object.h=Math.max(10,Math.abs(p.y-g.start.y));}
    if(g.type==='move'){g.object.x=g.before.x+p.x-g.start.x;g.object.y=g.before.y+p.y-g.start.y;}
    if(g.type==='resize'){g.object.w=Math.max(60,g.before.w+p.x-g.start.x);g.object.h=Math.max(40,g.before.h+p.y-g.start.y);}
    renderBoard();
  });
  function endGesture(){const g=state.gesture;state.gesture=null;if(!g||g.type==='pan')return;if(g.type==='move'&&g.object.x===g.before.x&&g.object.y===g.before.y)return;if(g.type==='stroke'&&g.object.points.length===1)g.object.points.push([g.object.points[0][0]+.1,g.object.points[0][1]+.1]);save(g.object,true,g.before||null);}
  on(viewport,'pointerup',endGesture);on(viewport,'pointercancel',endGesture);on(viewport,'pointerleave',()=>{if(!state.gesture)state.cursor=null;});
  on(viewport,'dblclick',e=>{const el=e.target.closest('.board-object');if(!el)return;const o=state.objects.get(el.dataset.id);if(['note','text'].includes(o.type))editText(o);});
  on(viewport,'wheel',e=>{if(e.target.closest('#video-grid'))return;e.preventDefault();if(e.ctrlKey||e.metaKey){zoom(state.zoom*Math.exp(-e.deltaY*.003),{x:e.clientX-viewport.getBoundingClientRect().left,y:e.clientY-viewport.getBoundingClientRect().top});}else{state.pan.x-=e.deltaX;state.pan.y-=e.deltaY;transform();}},{passive:false});
  function zoom(z,anchor={x:viewport.clientWidth/2,y:viewport.clientHeight/2}){z=Math.max(.2,Math.min(3,z));const ratio=z/state.zoom;state.pan={x:anchor.x-(anchor.x-state.pan.x)*ratio,y:anchor.y-(anchor.y-state.pan.y)*ratio};state.zoom=z;transform();}
  function fit(){const a=[...state.objects.values()];if(!a.length){state.pan={x:0,y:0};state.zoom=1;transform();return;}let x1=Infinity,y1=Infinity,x2=-Infinity,y2=-Infinity;for(const o of a){const pts=o.type==='stroke'?o.points:[[o.x,o.y],[o.x+o.w,o.y+o.h]];for(const p of pts){x1=Math.min(x1,p[0]);y1=Math.min(y1,p[1]);x2=Math.max(x2,p[0]);y2=Math.max(y2,p[1]);}}const w=viewport.clientWidth-130,h=viewport.clientHeight-90;state.zoom=Math.max(.2,Math.min(1.4,w/Math.max(x2-x1,50),h/Math.max(y2-y1,50)));state.pan={x:80+(w-(x2-x1)*state.zoom)/2-x1*state.zoom,y:25+(h-(y2-y1)*state.zoom)/2-y1*state.zoom};transform();}
  async function upload(file){
    if(!file)return;if(!['image/png','image/jpeg','image/webp','image/gif'].includes(file.type)){toast('Выберите PNG, JPG, WebP или GIF');return;}if(file.size>3*1024*1024){toast('Максимальный размер изображения — 3 МБ');return;}
    try{
      toast('Добавляем изображение…');let url;
      if(state.joined){const res=await fetch(`/api/upload?room=${state.room}&client=${state.client}`,{method:'POST',headers:{'x-session':state.token,'content-type':file.type},body:file});const data=await res.json();if(!res.ok)throw new Error(data.error);url=data.url;}
      else{url=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(file);});}
      const image=new Image();image.src=url;await image.decode();const ratio=Math.min(1,350/image.width,280/image.height);const w=image.width*ratio+16,h=image.height*ratio+16;
      const o={...defaults,id:uid(),type:'image',url,w,h,x:(viewport.clientWidth*.55-state.pan.x)/state.zoom-w/2,y:(viewport.clientHeight*.5-state.pan.y)/state.zoom-h/2,author:state.client};await save(o);state.selected=o.id;setTool('cursor');renderBoard();toast('Изображение на доске');
    }catch(err){toast(err.message||'Не удалось добавить изображение');}
  }
  on($('#image-input'),'change',e=>{upload(e.target.files[0]);e.target.value='';});
  on(viewport,'dragover',e=>{e.preventDefault();if(!$('#drag-overlay')){const el=document.createElement('div');el.id='drag-overlay';el.className='drag-overlay';el.textContent='Отпустите, чтобы добавить изображение';viewport.append(el);}});
  on(viewport,'dragleave',e=>{if(!viewport.contains(e.relatedTarget))$('#drag-overlay')?.remove();});
  on(viewport,'drop',e=>{e.preventDefault();$('#drag-overlay')?.remove();upload(e.dataTransfer.files[0]);});
  on(document,'paste',e=>{if(e.target.matches('input,textarea'))return;const file=[...e.clipboardData.items].find(i=>i.type.startsWith('image/'))?.getAsFile();if(file){e.preventDefault();upload(file);}});
  function renderCursors(){const el=$('#cursors');el.innerHTML=state.people.filter(p=>p.id!==state.client&&p.state.cursor).map(p=>`<div class="remote-cursor" style="transform:translate(${p.state.cursor.x}px,${p.state.cursor.y}px);--cursor-color:${p.color}">${icon('cursor')}<span>${escape(p.name)}</span></div>`).join('');}
  function renderPeople(){
    $('#member-count').textContent=state.people.length||1;
    const strip=$('#video-strip');const remote=state.people.filter(p=>p.id!==state.client);
    strip.querySelectorAll('.person-tile.remote').forEach(el=>{if(!remote.some(p=>p.id===el.dataset.client))el.remove();});
    for(const p of remote){let el=strip.querySelector(`[data-client="${p.id}"]`);if(!el){el=document.createElement('div');el.className='person-tile remote';el.dataset.client=p.id;el.innerHTML=`<div class="person-art"><span class="person-initial">${escape(p.name[0].toUpperCase())}</span><span class="orbit"></span></div><video autoplay playsinline hidden></video><div class="tile-label"><span></span>${icon('micoff')}</div><span class="tile-badge"></span>`;strip.insertBefore(el,$('.empty-tile'));}
      const label=el.querySelector('.tile-label');label.querySelector('span').textContent=p.name+(p.state.hand?' ✋':'');label.querySelector('svg').outerHTML=icon(p.state.mic?'mic':'micoff');
      const peer=state.peers.get(p.id);const video=el.querySelector('video');if(peer?.stream&&video.srcObject!==peer.stream)video.srcObject=peer.stream;video.hidden=!p.state.camera&&!peer?.screen;
      const badge=el.querySelector('.tile-badge');badge.textContent=peer?.pc.connectionState==='connected'?(p.state.camera?'':'Камера выключена'):'Соединяемся…';badge.hidden=p.state.camera&&peer?.pc.connectionState==='connected';
    }
    $('.empty-tile').hidden=remote.length>=3;$('.strip-note').hidden=remote.length>0;
    if(root.classList.contains('view-video'))renderGrid();renderCursors();if(state.panel==='people')renderPanel();
  }
  function renderGrid(){
    const grid=$('#video-grid');const originals=[...$('#video-strip').querySelectorAll('.person-tile')];
    const ids=originals.map(el=>el.dataset.client||'self');grid.querySelectorAll('.person-tile').forEach(el=>{if(!ids.includes(el.dataset.client))el.remove();});
    for(const original of originals){const id=original.dataset.client||'self';let el=grid.querySelector(`[data-client="${id}"]`);if(!el){el=original.cloneNode(true);el.removeAttribute('id');el.dataset.client=id;el.querySelector('video').removeAttribute('id');grid.append(el);}el.querySelector('.tile-label').innerHTML=original.querySelector('.tile-label').innerHTML;el.querySelector('.tile-badge').textContent=original.querySelector('.tile-badge').textContent;
      const ov=original.querySelector('video'),v=el.querySelector('video');v.hidden=ov.hidden;v.muted=id==='self';if(v.srcObject!==ov.srcObject)v.srcObject=ov.srcObject;}
    grid.style.gridTemplateColumns=originals.length===1?'1fr':'';
  }
  function view(mode){root.classList.toggle('view-video',mode==='video');$('#video-grid').hidden=mode!=='video';root.querySelectorAll('.board-tab,.rail-button[data-action="board"],.rail-button[data-action="video"]').forEach(el=>el.classList.toggle('active',el.dataset.action===mode));if(mode==='video')renderGrid();}
  async function sync(initial=false){
    if(syncing)return;
    syncing=true;
    try{
    const data=await api('sync',undefined,`&since=${state.since}${initial?'&initial=1':''}`);
    if(state.dead||!state.joined)return;
    state.failures=0;$('#connection').innerHTML='<i></i> '+(data.people.length>1?'Вы на одной волне':'Ждём ваш круг');
    state.people=data.people;
    if(initial){state.objects.clear();for(const o of data.objects)state.objects.set(o.id,o);state.messages=data.messages;}
    for(const [id,peer] of state.peers){const p=state.people.find(p=>p.id===id);if(!p||p.state.epoch!==peer.epoch){peer.pc.close();state.peers.delete(id);}}
    for(const event of data.events||[]){
      if(event.type==='object'&&!state.pending.has(event.data.id)&&state.gesture?.object?.id!==event.data.id)state.objects.set(event.data.id,event.data);
      if(event.type==='delete'&&!state.pending.has(event.data.id))state.objects.delete(event.data.id);
      if(event.type==='chat'&&!state.messages.some(m=>m.id===event.id)){state.messages.push(event);if(state.panel!=='chat')root.querySelectorAll('.unread-dot').forEach(el=>el.hidden=false);}
      if(event.type==='signal'&&!state.signals.has(event.id)){state.signals.add(event.id);await receiveSignal(event.author,event.data);}
    }
    state.since=data.since;renderBoard();renderPeople();if(state.panel==='chat')renderPanel();
    for(const p of state.people)if(p.id!==state.client&&!state.peers.has(p.id))createPeer(p.id);
    for(const [id,p] of state.peers)if(!state.people.some(m=>m.id===id)){p.pc.close();state.peers.delete(id);}
    }finally{syncing=false;}
  }
  function schedulePoll(){clearTimeout(pollTimer);pollTimer=later(async()=>{if(!state.joined)return;try{await sync();}catch(err){state.failures++;$('#connection').textContent='Восстанавливаем связь…';if(state.failures===3)toast('Связь прервалась. Пробуем восстановить соединение.');}schedulePoll();},state.failures?2500:750);}
  async function presence(){if(!state.joined)return;try{await api('presence',{mic:state.mic,camera:state.camera||!!state.screen,hand:state.hand,cursor:state.cursor});}catch{} }
  function schedulePresence(){clearTimeout(presenceTimer);presenceTimer=later(async()=>{if(!state.joined)return;await presence();schedulePresence();},1000);}
  function signal(target,message){return api('signal',{target,signal:message});}
  function createPeer(id){
    if(state.peers.has(id))return state.peers.get(id);
    const pc=new RTCPeerConnection({iceServers:state.iceServers});
    const peer={pc,epoch:state.people.find(p=>p.id===id)?.state.epoch,makingOffer:false,ignoreOffer:false,settingAnswer:false,polite:state.client.localeCompare(id)>0,stream:new MediaStream(),queue:[],audio:pc.addTransceiver('audio',{direction:'sendrecv'}),video:pc.addTransceiver('video',{direction:'sendrecv'})};
    state.peers.set(id,peer);
    const audio=state.localStream.getAudioTracks()[0],video=state.screen?.getVideoTracks()[0]||state.localStream.getVideoTracks()[0];
    if(audio)peer.audio.sender.replaceTrack(audio);if(video)peer.video.sender.replaceTrack(video);
    pc.onicecandidate=e=>{if(e.candidate)signal(id,{type:'ice',candidate:e.candidate.toJSON()}).catch(()=>{});};
    pc.ontrack=e=>{if(!peer.stream.getTracks().some(t=>t.id===e.track.id))peer.stream.addTrack(e.track);renderPeople();};
    pc.onconnectionstatechange=()=>{renderPeople();if(pc.connectionState==='failed')toast('Видеосвязь не установилась. Для этой сети может понадобиться TURN-сервер. Доска и чат продолжают работать.');};
    pc.onnegotiationneeded=async()=>{try{peer.makingOffer=true;await pc.setLocalDescription();await signal(id,{type:pc.localDescription.type,description:pc.localDescription.toJSON()});}catch(err){console.warn('Negotiation:',err.message);}finally{peer.makingOffer=false;}};
    return peer;
  }
  async function receiveSignal(id,message){
    if(id===state.client)return;const peer=createPeer(id),pc=peer.pc;
    try{
      if(message.type==='ice'){if(!pc.remoteDescription){peer.queue.push(message.candidate);return;}try{await pc.addIceCandidate(message.candidate);}catch(err){if(!peer.ignoreOffer)throw err;}return;}
      const description=message.description;if(!description)return;
      const ready=!peer.makingOffer&&(pc.signalingState==='stable'||peer.settingAnswer);
      const collision=description.type==='offer'&&!ready;peer.ignoreOffer=!peer.polite&&collision;if(peer.ignoreOffer)return;
      peer.settingAnswer=description.type==='answer';await pc.setRemoteDescription(description);peer.settingAnswer=false;
      for(const candidate of peer.queue.splice(0))await pc.addIceCandidate(candidate);
      if(description.type==='offer'){await pc.setLocalDescription();await signal(id,{type:'answer',description:pc.localDescription.toJSON()});}
    }catch(err){console.warn('Signal:',err.message);}
  }
  async function toggleMedia(kind){
    if(!state.joined){roomDialog(!!state.room);return;}
    const field=kind==='audio'?'mic':'camera',enabled=!state[field];
    try{
      let track=state.localStream.getTracks().find(t=>t.kind===kind&&t.readyState==='live');
      if(enabled&&!track){const stream=await navigator.mediaDevices.getUserMedia(kind==='audio'?{audio:{echoCancellation:true,noiseSuppression:true}}:{video:{width:{ideal:640},height:{ideal:360},frameRate:{ideal:20}}});track=stream.getTracks()[0];state.localStream.addTrack(track);for(const peer of state.peers.values())await peer[kind==='audio'?'audio':'video'].sender.replaceTrack(kind==='video'&&state.screen?state.screen.getVideoTracks()[0]:track);}
      if(track)track.enabled=enabled;state[field]=enabled;updateMedia();await presence();
    }catch(err){toast(err.name==='NotAllowedError'?'Разрешите доступ к '+(kind==='audio'?'микрофону':'камере')+' в настройках браузера.':err.name==='NotFoundError'?'Браузер не нашёл '+(kind==='audio'?'микрофон':'камеру')+'. Доска остаётся доступной.':'Не удалось включить '+(kind==='audio'?'микрофон':'камеру')+'.');}
  }
  function updateMedia(){
    const local=$('#local-video');local.srcObject=state.screen||state.localStream;local.hidden=!state.camera&&!state.screen;
    const mic=$('[data-action="mic"]'),camera=$('[data-action="camera"]');mic.classList.toggle('off',!state.mic);mic.classList.toggle('on',state.mic);mic.querySelector('svg').outerHTML=icon(state.mic?'mic':'micoff');mic.title=state.mic?'Выключить микрофон':'Включить микрофон';mic.setAttribute('aria-label',mic.title);
    camera.classList.toggle('off',!state.camera);camera.classList.toggle('on',state.camera);camera.querySelector('svg').outerHTML=icon(state.camera?'video':'videooff');camera.title=state.camera?'Выключить камеру':'Включить камеру';camera.setAttribute('aria-label',camera.title);
    $('.self .tile-badge').hidden=state.camera||!!state.screen;$('.self .tile-label>svg').outerHTML=icon(state.mic?'mic':'micoff');$('[data-action="screen"]').classList.toggle('on',!!state.screen);if(root.classList.contains('view-video'))renderGrid();
  }
  async function screenShare(){
    if(!state.joined){roomDialog(!!state.room);return;}
    if(state.screen){stopScreen();return;}
    if(!navigator.mediaDevices.getDisplayMedia){toast('Этот браузер не поддерживает демонстрацию экрана.');return;}
    try{state.screen=await navigator.mediaDevices.getDisplayMedia({video:true,audio:false});const track=state.screen.getVideoTracks()[0];track.onended=stopScreen;for(const peer of state.peers.values())await peer.video.sender.replaceTrack(track);updateMedia();presence();toast('Вы делитесь экраном. Нажмите «Экран» ещё раз, чтобы остановить.');}catch(err){if(err.name!=='NotAllowedError')toast('Не удалось начать демонстрацию экрана');}
  }
  function stopScreen(){const stream=state.screen;state.screen=null;stream?.getTracks().forEach(t=>t.stop());const track=state.localStream.getVideoTracks()[0]||null;for(const peer of state.peers.values())peer.video.sender.replaceTrack(track).catch(()=>{});updateMedia();presence();}
  function renderPanel(){
    const content=$('#panel-content');
    if(state.panel==='people'){const people=state.joined?state.people:[{id:'self',name:state.name,color:state.color,state:{mic:false}}];content.innerHTML=people.map(p=>`<div class="participant-row"><span class="participant-avatar" style="color:${p.color}">${escape(p.name[0].toUpperCase())}</span><div><strong>${escape(p.name)}${p.id===state.client||p.id==='self'?' <small>это вы</small>':''}</strong><small>${p.state.hand?'✋ Рука поднята':p.state.camera?'Камера включена':'Камера выключена'}</small></div>${icon(p.state.mic?'mic':'micoff')}</div>`).join('')+`<button class="primary-button" data-action="invite">${icon('plus')} Пригласить коллег</button>`;return;}
    const wasBottom=content.scrollTop+content.clientHeight>=content.scrollHeight-60;
    content.innerHTML=state.messages.length?state.messages.map(m=>`<article class="chat-message"><div class="message-heading" style="color:${m.data.color||'#6d8159'}">${escape(m.data.name)}<time>${new Date(m.created).toLocaleTimeString('ru',{hour:'2-digit',minute:'2-digit'})}</time></div><div class="message-text">${escape(m.data.text)}</div></article>`).join(''):`<div class="panel-empty">${icon('chat')}Каждый разговор<br>начинается с «Привет!»<br><br>${state.joined?'Напишите первое сообщение.':'Создайте встречу, чтобы начать разговор.'}</div>`;
    if(wasBottom)content.scrollTop=content.scrollHeight;
  }
  function panel(mode){if(state.panel===mode)mode=null;state.panel=mode;$('#side-panel').hidden=!mode;$('#chat-form').hidden=mode!=='chat';$('#panel-title').textContent=mode==='people'?'Участники встречи':'Чат встречи';if(mode==='chat')root.querySelectorAll('.unread-dot').forEach(el=>el.hidden=true);if(mode)renderPanel();}
  on($('#chat-form'),'submit',async e=>{e.preventDefault();if(!state.joined){roomDialog(!!state.room);return;}const input=$('#chat-input'),text=input.value.trim();if(!text)return;input.disabled=true;try{await api('chat',{text});input.value='';await sync();}catch(err){toast(err.message);}finally{input.disabled=false;input.focus();}});
  function exportBoard(){
    const list=[...state.objects.values()];if(!list.length){toast('Добавьте на доску первую идею');return;}
    // Export a self-contained SVG. Shared uploaded images are embedded below.
    Promise.all(list.map(async o=>{if(o.type!=='image'||o.url.startsWith('data:'))return o;try{const res=await fetch(o.url);const blob=await res.blob();const data=await new Promise(resolve=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.readAsDataURL(blob);});return{...o,url:data};}catch{return o;}})).then(a=>{
      let x1=Infinity,y1=Infinity,x2=-Infinity,y2=-Infinity;for(const o of a){for(const p of o.type==='stroke'?o.points:[[o.x,o.y],[o.x+o.w,o.y+o.h]]){x1=Math.min(x1,p[0]);y1=Math.min(y1,p[1]);x2=Math.max(x2,p[0]);y2=Math.max(y2,p[1]);}}
      const xmlEscape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
      const markup=a.map(o=>{if(o.type==='stroke')return`<polyline points="${o.points.map(p=>p.join(',')).join(' ')}" fill="none" stroke="${o.color}" stroke-width="${o.size}" stroke-linecap="round" stroke-linejoin="round"/>`;let inner='';if(o.type==='image')inner=`<image href="${xmlEscape(o.url)}" x="0" y="0" width="${o.w}" height="${o.h}" preserveAspectRatio="xMidYMid meet"/>`;if(o.type==='rect'||o.type==='ellipse')inner=o.type==='rect'?`<rect width="${o.w}" height="${o.h}" fill="none" stroke="${o.color}" stroke-width="2"/>`:`<ellipse cx="${o.w/2}" cy="${o.h/2}" rx="${o.w/2}" ry="${o.h/2}" fill="none" stroke="${o.color}" stroke-width="2"/>`;if(o.type==='note')inner=`<rect width="${o.w}" height="${o.h}" fill="${o.color}"/>`;if(['note','text'].includes(o.type)){const font=o.type==='note'?15:o.size||18;const pad=o.type==='note'?22:3;const lines=[];for(const line of o.text.split('\n')){const max=Math.max(8,Math.floor((o.w-pad*2)/(font*.54)));if(!line){lines.push('');continue;}let current='';for(const word of line.split(' ')){if((current+' '+word).length>max&&current){lines.push(current);current=word;}else current+=(current?' ':'')+word;}lines.push(current);}inner+=`<text x="${pad}" y="${pad+font}" font-family="Arial,sans-serif" font-size="${font}" fill="${o.type==='note'?'#444937':o.color}">${lines.map((l,i)=>`<tspan x="${pad}" dy="${i?font*1.5:0}">${xmlEscape(l)}</tspan>`).join('')}</text>`;}return`<g transform="translate(${o.x} ${o.y}) rotate(${o.rotation||0} ${o.w/2} ${o.h/2})">${inner}</g>`;}).join('');
      const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${x2-x1+80}" height="${y2-y1+80}" viewBox="${x1-40} ${y1-40} ${x2-x1+80} ${y2-y1+80}"><rect x="${x1-40}" y="${y1-40}" width="${x2-x1+80}" height="${y2-y1+80}" fill="#fafbf7"/>${markup}</svg>`;
      const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml'})),ael=document.createElement('a');ael.href=url;ael.download='КРУГ — общая доска.svg';ael.click();later(()=>URL.revokeObjectURL(url),5000);toast('Доска скачана в SVG');
    });
  }
  function leave(){
    if(!state.joined){roomDialog(!!state.room);return;}
    showModal(`${symbol('leave')}<h2>Выйти из круга?</h2><p>Доска останется в комнате. Вы сможете вернуться к ней по той же ссылке.</p><button class="primary-button" data-action="confirm-leave">Выйти из встречи</button><button class="secondary-button" data-action="close-modal">Остаться с командой</button>`);
  }
  async function perform(action){
    switch(action){
      case'invite':inviteDialog();break;case'close-modal':modal.close();break;case'help':help();break;case'board':view('board');break;case'video':view('video');break;case'chat':panel('chat');break;case'people':panel('people');break;case'close-panel':panel(null);break;
      case'copy':try{await navigator.clipboard.writeText(location.href);const btn=$('[data-action="copy"]');btn.innerHTML=icon('check')+' Готово';toast('Ссылка скопирована');}catch{$('#invite-url').select();toast('Выделите ссылку и скопируйте её');}break;
      case'mic':await toggleMedia('audio');break;case'camera':await toggleMedia('video');break;case'screen':await screenShare();break;
      case'hand':if(!state.joined){roomDialog(!!state.room);break;}state.hand=!state.hand;$('[data-action="hand"]').classList.toggle('on',state.hand);presence();toast(state.hand?'Рука поднята':'Рука опущена');break;
      case'zoom-in':zoom(state.zoom*1.2);break;case'zoom-out':zoom(state.zoom/1.2);break;case'reset-zoom':zoom(1);break;case'fit':fit();break;case'undo':await undo();break;case'redo':await undo(true);break;
      case'delete-object':await remove(state.selected);break;case'edit-object':if(state.objects.get(state.selected))editText(state.objects.get(state.selected));break;case'export':exportBoard();break;case'leave':leave();break;
      case'confirm-leave':try{await api('leave',{});}catch{}state.joined=false;clearTimeout(pollTimer);clearTimeout(presenceTimer);state.localStream.getTracks().forEach(t=>t.stop());stopScreen();for(const peer of state.peers.values())peer.pc.close();state.peers.clear();state.mic=false;state.camera=false;updateMedia();modal.close();showModal(`${symbol('check')}<h2>Спасибо за встречу.</h2><p>Ваши идеи остались на общей доске. Возвращайтесь к ним, когда будете готовы.</p><button class="primary-button" data-action="rejoin">Вернуться во встречу</button><button class="secondary-button" data-action="home">Новая пробная доска</button>`);break;
      case'rejoin':roomDialog(true);break;case'home':location.href='/';break;
      case'profile':if(!state.joined)roomDialog(!!state.room);else toast('Вы во встрече как '+state.name);break;
    }
  }
  on(root,'click',e=>{const tool=e.target.closest('[data-tool]');if(tool){setTool(tool.dataset.tool);return;}const color=e.target.closest('[data-color]');if(color){state.color=color.dataset.color;root.querySelectorAll('[data-color]').forEach(b=>b.classList.toggle('active',b===color));return;}const button=e.target.closest('[data-action]');if(button)perform(button.dataset.action).catch(err=>toast(err.message));});
  on(document,'keydown',e=>{
    if(e.target.matches('input,textarea')||modal.open)return;
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();undo(e.shiftKey);return;}
    if(e.key==='Delete'||e.key==='Backspace'){if(state.selected){e.preventDefault();remove(state.selected);}return;}
    if(e.key==='Escape'){state.selected=null;setTool('cursor');panel(null);renderBoard();return;}
    if(e.key==='?'){help();return;}
    const keys={v:'cursor',h:'hand',p:'pen',t:'text',n:'note',r:'shape',i:'image',м:'cursor',р:'hand',з:'pen',е:'text',т:'note',к:'shape',ш:'image'};if(keys[e.key.toLowerCase()]&&!e.ctrlKey&&!e.metaKey)setTool(keys[e.key.toLowerCase()]);
  });
  on(modal,'click',e=>{if(e.target===modal){const r=modal.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)modal.close();}});
  on(window,'beforeunload',()=>{if(state.joined)navigator.sendBeacon('/api/leave',JSON.stringify({room:state.room,client:state.client,token:state.token}));});
  function tick(){const elapsed=Math.floor((Date.now()-state.started)/1000);$('#meeting-time').textContent=`${String(Math.floor(elapsed/60)).padStart(2,'0')}:${String(elapsed%60).padStart(2,'0')}`;later(tick,1000);}
  demoSeed();setSaveStatus();tick();
  if(state.room)roomDialog(true);
  else{const label=document.createElement('div');label.id='demo-label';label.className='demo-label';label.innerHTML='ПРОБНАЯ ДОСКА · <button class="start-link" data-action="invite">Создать встречу</button>';viewport.append(label);}
  return()=>{state.dead=true;abort.abort();timers.forEach(clearTimeout);state.localStream.getTracks().forEach(t=>t.stop());state.screen?.getTracks().forEach(t=>t.stop());state.peers.forEach(p=>p.pc.close());delete root.dataset.started;};
}

