type Statement = { bind(...values: any[]): Statement; first(): Promise<any>; all(): Promise<{results:any[]}>; run(): Promise<any> };
type Bindings = { DB?: { prepare(sql:string): Statement; batch(statements:Statement[]):Promise<any> }; BUCKET?: { get(key:string):Promise<any>; put(key:string,bytes:ArrayBuffer,options:any):Promise<any> }; TURN_URL?: string; TURN_USERNAME?: string; TURN_PASSWORD?: string };
const COLORS = ["#56724b", "#ad7651", "#8069a5", "#427f9a"];
const json = (data: unknown, status = 200) => Response.json(data, { status, headers: { "Cache-Control": "no-store" } });
const uid = () => crypto.randomUUID().replaceAll("-", "");
const validId = (s: unknown) => typeof s === "string" && /^[a-zA-Z0-9_-]{8,64}$/.test(s);
const clamp = (n: unknown, lo: number, hi: number, def = 0) => typeof n === "number" && Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : def;

export async function handle(request: Request, env: Bindings): Promise<Response> {
  try {
    const url = new URL(request.url), action = url.pathname.slice(5), db = env.DB;
    if (!db) return json({ error: "Для совместных встреч подключите PostgreSQL и задайте DATABASE_URL в настройках проекта Vercel." }, 503);
    if (request.method === "POST" && request.headers.get("origin") && request.headers.get("origin") !== url.origin) return json({ error: "Недопустимый источник запроса" }, 403);
    if (Number(request.headers.get("content-length") || 0) > 4 * 1024 * 1024) return json({ error: "Файл слишком большой. Максимум — 3 МБ." }, 413);
    let body: any = {};
    if (request.method === "POST" && action !== "upload") {
      const raw = await request.text();
      if (raw.length > 160000) return json({ error: "Слишком большой запрос" }, 413);
      try { body = JSON.parse(raw); } catch { return json({ error: "Некорректный запрос" }, 400); }
    }
    if (action === "create" && request.method === "POST") {
      const id = uid(), owner = uid(), title = String(body.title || "Дизайн-сессия").trim().slice(0, 80) || "Новая встреча";
      await db.prepare("INSERT INTO rooms (id, title, owner, created) VALUES (?, ?, ?, ?)").bind(id, title, owner, Date.now()).run();
      return json({ room: id, owner });
    }
    if (action === "config") {
      const iceServers: any[] = [{ urls: ["stun:stun.l.google.com:19302", "stun:stun.cloudflare.com:3478"] }];
      if (env.TURN_URL && env.TURN_USERNAME && env.TURN_PASSWORD) iceServers.push({ urls: env.TURN_URL.split(","), username: env.TURN_USERNAME, credential: env.TURN_PASSWORD });
      return json({ iceServers, turnConfigured: iceServers.length > 1, maxMembers: 4 });
    }
    const room = body.room || url.searchParams.get("room");
    if (!validId(room)) return json({ error: "Ссылка на комнату некорректна" }, 400);
    const record: any = await db.prepare("SELECT * FROM rooms WHERE id = ?").bind(room).first();
    if (!record) return json({ error: "Комната не найдена. Проверьте ссылку или создайте новую встречу." }, 404);
    if (action.startsWith("image/") && request.method === "GET") {
      const imageId = action.slice(6);
      if (!validId(imageId)) return json({ error: "Изображение не найдено" }, 404);
      const item = await env.BUCKET?.get(`${room}/${imageId}`);
      if (!item) return json({ error: "Изображение не найдено" }, 404);
      const headers = new Headers({ "Cache-Control": "private, max-age=3600", "X-Content-Type-Options": "nosniff" });
      item.writeHttpMetadata(headers);
      return new Response(item.body, { headers });
    }
    if (action === "join" && request.method === "POST") {
      const name = String(body.name || "Участник").trim().slice(0, 40) || "Участник";
      const previous: any = validId(body.client) && body.token ? await db.prepare("SELECT * FROM members WHERE room = ? AND id = ? AND token = ?").bind(room, body.client, body.token).first() : null;
      const count: any = await db.prepare("SELECT COUNT(*) as n FROM members WHERE room = ? AND seen > ? AND id != ?").bind(room, Date.now() - 18000, previous?.id || "").first();
      if (count.n >= 4) return json({ error: "В комнате уже 4 участника. Попробуйте присоединиться позже." }, 409);
      const client = previous?.id || uid(), token = previous?.token || uid(), color = previous?.color || COLORS[count.n % 4];
      const state = JSON.stringify({ mic: false, camera: false, hand: false, cursor: null, epoch:uid() });
      // The request wrapper holds the room lock until this transaction commits.
      const inserted = await db.prepare("INSERT INTO members (room,id,token,name,color,seen,state) SELECT ?,?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM members WHERE room=? AND seen>? AND id!=?) < 4 ON CONFLICT(room,id) DO UPDATE SET seen=excluded.seen,name=excluded.name,state=excluded.state RETURNING id").bind(room, client, token, name, color, Date.now(), state, room,Date.now()-18000,client).first();
      if(!inserted) return json({ error: "В комнате уже 4 участника. Попробуйте присоединиться позже." }, 409);
      return json({ client, token, color, title: record.title, owner: body.owner === record.owner });
    }
    const client = body.client || url.searchParams.get("client"), token = request.headers.get("x-session") || body.token;
    if (!validId(client) || !token) return json({ error: "Сначала присоединитесь к комнате" }, 401);
    const member: any = await db.prepare("SELECT * FROM members WHERE room = ? AND id = ? AND token = ?").bind(room, client, token).first();
    if (!member) return json({ error: "Сессия завершилась. Войдите в комнату снова." }, 401);
    const emit = (type: string, data: any, target: string | null = null) => db.prepare("INSERT INTO events (room,type,author,target,data,created) VALUES (?,?,?,?,?,?)").bind(room, type, client, target, JSON.stringify(data), Date.now());
    if (action === "sync" && request.method === "GET") {
      await db.prepare("UPDATE members SET seen = ? WHERE room = ? AND id = ?").bind(Date.now(), room, client).run();
      const since = Math.max(0, Number(url.searchParams.get("since") || 0));
      const people = await db.prepare("SELECT id,name,color,state FROM members WHERE room = ? AND seen > ? ORDER BY id").bind(room, Date.now() - 18000).all();
      const participants = people.results.map((p: any) => ({ ...p, state: JSON.parse(p.state) }));
      if (url.searchParams.get("initial") === "1") {
        // Capture the cursor first: concurrent edits can replay safely but cannot be lost.
        const max: any = await db.prepare("SELECT MAX(id) as id FROM events WHERE room = ?").bind(room).first();
        const board = await db.prepare("SELECT data FROM objects WHERE room = ? ORDER BY ordinal").bind(room).all();
        const messages = await db.prepare("SELECT id,author,data,created FROM events WHERE room = ? AND type = 'chat' ORDER BY id DESC LIMIT 80").bind(room).all();
        const signals = await db.prepare("SELECT id,type,author,data,created FROM events WHERE room=? AND target=? AND type='signal' AND created>? ORDER BY id LIMIT 60").bind(room,client,Date.now()-15000).all();
        return json({ people: participants, objects: board.results.map((o: any) => JSON.parse(o.data)), messages: messages.results.reverse().map((e: any) => ({ ...e, data: JSON.parse(e.data) })), events: signals.results.map((e:any)=>({ ...e, data:JSON.parse(e.data) })), since: max?.id || 0 });
      }
      const rows = await db.prepare("SELECT id,type,author,target,data,created FROM events WHERE room = ? AND id > ? ORDER BY id LIMIT 12").bind(room, since).all();
      return json({ people: participants, events: rows.results.filter((e: any) => !e.target || e.target === client).map((e: any) => ({ ...e, data: JSON.parse(e.data) })), since: (rows.results.at(-1) as any)?.id || since });
    }
    if (action === "presence" && request.method === "POST") {
      const cursor = body.cursor && Number.isFinite(body.cursor.x) && Number.isFinite(body.cursor.y) ? { x: clamp(body.cursor.x,-10000,10000), y: clamp(body.cursor.y,-10000,10000) } : null;
      await db.prepare("UPDATE members SET state=?,seen=? WHERE room=? AND id=?").bind(JSON.stringify({ mic: !!body.mic, camera: !!body.camera, hand: !!body.hand, cursor, epoch:JSON.parse(member.state).epoch }), Date.now(), room, client).run();
      return json({ ok: true });
    }
    if (action === "object" && request.method === "POST") {
      const o = sanitizeObject(body.object, client);
      if (!o) return json({ error: "Не удалось сохранить объект" }, 400);
      const count: any = await db.prepare("SELECT COUNT(*) as n FROM objects WHERE room=?").bind(room).first();
      const exists = await db.prepare("SELECT id FROM objects WHERE room=? AND id=?").bind(room,o.id).first();
      if (!exists && count.n >= 800) return json({ error: "На доске уже 800 объектов. Удалите ненужные." }, 409);
      const bytes:any = await db.prepare("SELECT COALESCE(SUM(octet_length(data)),0)::bigint as n FROM objects WHERE room=? AND id!=?").bind(room,o.id).first();
      if(Number(bytes.n)+new TextEncoder().encode(JSON.stringify(o)).byteLength>2*1024*1024) return json({error:"Доска заполнена. Скачайте её и удалите ненужные объекты."},409);
      await db.batch([db.prepare("INSERT INTO objects (room,id,data,author) VALUES (?,?,?,?) ON CONFLICT(room,id) DO UPDATE SET data=excluded.data").bind(room,o.id,JSON.stringify(o),client), emit("object",o)]);
      return json({ ok: true });
    }
    if (action === "delete" && request.method === "POST") {
      if (!validId(body.id)) return json({ error: "Некорректный объект" }, 400);
      await db.batch([db.prepare("DELETE FROM objects WHERE room=? AND id=?").bind(room,body.id), emit("delete",{ id: body.id })]);
      return json({ ok: true });
    }
    if (action === "chat" && request.method === "POST") {
      const text = String(body.text || "").trim().slice(0,2000);
      if (!text) return json({ error: "Напишите сообщение" }, 400);
      await emit("chat",{ text, name: member.name, color: member.color }).run();
      return json({ ok: true });
    }
    if (action === "signal" && request.method === "POST") {
      if (!validId(body.target) || !body.signal || !["offer","answer","ice"].includes(body.signal.type)) return json({ error: "Некорректный сигнал" }, 400);
      if(JSON.stringify(body.signal).length>30000) return json({error:"Сигнал слишком большой"},413);
      await emit("signal",body.signal,body.target).run();
      return json({ ok: true });
    }
    if (action === "upload" && request.method === "POST") {
      if (!env.BUCKET) return json({ error: "Хранилище изображений недоступно" }, 503);
      const type = request.headers.get("content-type") || "";
      if (!["image/png","image/jpeg","image/webp","image/gif"].includes(type)) return json({ error: "Поддерживаются PNG, JPG, WebP и GIF" }, 400);
      const bytes = await request.arrayBuffer();
      if (bytes.byteLength > 3 * 1024 * 1024) return json({ error: "Максимальный размер — 3 МБ" }, 413);
      const id = uid();
      await env.BUCKET.put(`${room}/${id}`, bytes, { httpMetadata: { contentType: type } });
      return json({ url: `/api/image/${id}?room=${room}` });
    }
    if (action === "leave" && request.method === "POST") {
      await db.prepare("UPDATE members SET seen=0 WHERE room=? AND id=?").bind(room,client).run();
      return json({ ok:true });
    }
    return json({ error: "Метод не найден" }, 404);
  } catch (err) {
    console.error("Room API", (err as Error).message);
    return json({ error: "Не удалось связаться с комнатой. Попробуйте ещё раз." }, 500);
  }
}

function sanitizeObject(input: any, author: string): any | null {
  if (!input || !validId(input.id) || !["note","text","stroke","rect","ellipse","image"].includes(input.type)) return null;
  const o: any = { id:input.id, type:input.type, author, x:clamp(input.x,-10000,10000),y:clamp(input.y,-10000,10000), w:clamp(input.w,10,2500,220), h:clamp(input.h,10,2500,160), rotation:clamp(input.rotation,-180,180),color:/^#[0-9a-f]{6}$/i.test(input.color)?input.color:"#324735",size:clamp(input.size,1,80,3) };
  if (["text","note"].includes(o.type)) o.text=String(input.text || "").slice(0,4000);
  if (o.type === "stroke") {
    if (!Array.isArray(input.points) || input.points.length > 3000) return null;
    o.points = input.points.filter((p:any)=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite)).map((p:any)=>[clamp(p[0],-10000,10000),clamp(p[1],-10000,10000)]);
  }
  if (o.type === "image") {
    if (typeof input.url !== "string" || !/^\/api\/image\/[a-zA-Z0-9_-]{8,64}\?room=[a-zA-Z0-9_-]{8,64}$/.test(input.url)) return null;
    o.url=input.url;
  }
  return o;
}
