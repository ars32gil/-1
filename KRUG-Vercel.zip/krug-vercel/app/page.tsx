"use client";
import { useEffect } from "react";
import { shell } from "./ui";
export default function Home() {
  useEffect(() => {
    let dispose: (() => void) | undefined;
    let cancelled = false;
    import("./client.js").then(({ start }) => { if (!cancelled) dispose = start(); });
    return () => { cancelled = true; dispose?.(); };
  }, []);
  return <main id="krug" dangerouslySetInnerHTML={{ __html: shell }} />;
}
