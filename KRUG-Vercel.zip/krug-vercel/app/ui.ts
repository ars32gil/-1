const paths: Record<string, string> = {
  arrow: '<path d="m9 5 7 7-7 7"/>', plus: '<path d="M12 5v14M5 12h14"/>',
  board: '<rect x="3" y="4" width="18" height="14" rx="2"/><path d="M9 22l3-4 3 4M8 9h8M8 13h5"/>',
  video: '<rect x="3" y="6" width="12" height="12" rx="3"/><path d="m15 10 6-4v12l-6-4"/>',
  videooff: '<path d="m3 3 18 18M15 10l6-4v12l-6-4M10 6h2a3 3 0 0 1 3 3M15 15a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V9a3 3 0 0 1 1-2"/>',
  mic: '<rect x="9" y="2" width="6" height="13" rx="3"/><path d="M5 10v2a7 7 0 0 0 14 0v-2M12 19v3M8 22h8"/>',
  micoff: '<path d="m3 3 18 18M9 9v3a3 3 0 0 0 5 2M9 5a3 3 0 0 1 6 0v6M5 10v2a7 7 0 0 0 12 5M19 10v2a7 7 0 0 1-1 4M12 19v3M8 22h8"/>',
  share: '<rect x="3" y="3" width="18" height="14" rx="2"/><path d="M12 13V6m-3 3 3-3 3 3M8 21h8M12 17v4"/>',
  people: '<circle cx="9" cy="8" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3M17 5a3 3 0 0 1 0 6M18 15a5 5 0 0 1 3 4v2"/>',
  chat: '<path d="M21 11a9 9 0 0 1-9 9H3l2-5a9 9 0 1 1 16-4Z"/><path d="M8 10h8M8 14h5"/>',
  hand: '<path d="M8 12V5a2 2 0 0 1 4 0v7-9a2 2 0 0 1 4 0v9-6a2 2 0 0 1 4 0v9a7 7 0 0 1-12 5l-5-6a2 2 0 0 1 3-3l2 1Z"/>',
  leave: '<path d="M4 13a15 15 0 0 1 16 0l1 4a1 1 0 0 1-1 1l-4-1v-3a10 10 0 0 0-8 0v3l-4 1a1 1 0 0 1-1-1Z"/>',
  cursor: '<path d="m5 3 14 9-7 1-4 7Z"/>', pen: '<path d="m15 4 5 5M4 20l5-1L20 8a3.5 3.5 0 0 0-5-5L4 14Z"/>',
  text: '<path d="M4 5h16M12 5v15M8 20h8M4 5v3M20 5v3"/>', note: '<path d="M4 4h16v12l-4 4H4Z"/><path d="M15 20v-5h5"/>',
  shape: '<rect x="4" y="4" width="16" height="16" rx="3"/>', image: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="1.5"/><path d="m21 15-5-5L5 21"/>',
  undo: '<path d="m8 4-5 5 5 5M3 9h11a7 7 0 0 1 0 14"/>', redo: '<path d="m16 4 5 5-5 5M21 9H10a7 7 0 0 0 0 14"/>',
  minus: '<path d="M5 12h14"/>', fit: '<path d="M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5"/>',
  download: '<path d="M12 3v12m-4-4 4 4 4-4M4 16v5h16v-5"/>', more: '<circle cx="4" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="20" cy="12" r="1"/>',
  check: '<path d="m5 12 4 4L19 6"/>', link: '<path d="m10 14 4-4M8 16l-2 2a4 4 0 0 1-6-6l4-4a4 4 0 0 1 6 0m4-2 2-2a4 4 0 0 1 6 6l-4 4a4 4 0 0 1-6 0"/>',
  close: '<path d="m6 6 12 12M6 18 18 6"/>', send: '<path d="m22 2-7 20-4-9-9-4ZM22 2 11 13"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>', trash: '<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
};
export const icon = (name: string, cls = "") => `<svg class="icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.plus}</svg>`;
const tool = (name: string, label: string, key: string) => `<button class="tool ${name === 'cursor' ? 'active' : ''}" data-tool="${name}" title="${label} (${key})" aria-label="${label}" aria-pressed="${name === 'cursor'}">${icon(name)}<span>${key}</span></button>`;
export const shell = `
<aside class="rail">
  <a href="/" class="brand" aria-label="КРУГ — главная"><span class="brand-symbol"><i></i><i></i></span><b>круг</b></a>
  <div class="rail-separator"></div>
  <button class="rail-button active" data-action="board" title="Общая доска" aria-label="Общая доска">${icon('board')}</button>
  <button class="rail-button" data-action="video" title="Видеовстреча" aria-label="Видеовстреча">${icon('video')}</button>
  <button class="rail-button" data-action="chat" title="Чат" aria-label="Чат">${icon('chat')}<span class="unread-dot" hidden></span></button>
  <div class="rail-bottom"><button class="rail-button" data-action="help" title="Как пользоваться" aria-label="Как пользоваться">${icon('info')}</button><button class="my-avatar" data-action="profile" aria-label="Ваше имя">В</button></div>
</aside>
<div class="workspace">
  <header class="topbar">
    <div class="room-title"><div class="breadcrumb">РАБОЧЕЕ ПРОСТРАНСТВО <span>/</span> ВСТРЕЧА</div><h1 id="room-title">Дизайн-сессия <span class="live-pill"><i></i><span id="room-status">Пробная доска</span></span></h1></div>
    <div class="header-actions"><span class="connection" id="connection"><i></i> Всё готово к идеям</span><button class="invite-button" data-action="invite">${icon('people')}<span>Пригласить</span>${icon('plus')}</button></div>
  </header>
  <section class="meeting-strip" aria-label="Участники встречи">
    <div class="strip-heading"><span><i class="live-dot"></i> МЫ В КРУГЕ <b id="member-count">1</b></span><span class="strip-caption">Лица рядом. Идеи на доске.</span><button data-action="video" class="subtle-button">${icon('grid')}<span>Все участники</span></button></div>
    <div class="video-strip" id="video-strip"><div class="person-tile self"><div class="person-art"><span class="person-initial">В</span><span class="orbit orbit-one"></span><span class="orbit orbit-two"></span></div><video id="local-video" autoplay muted playsinline hidden></video><div class="tile-label"><span id="local-name">Вы <small>это вы</small></span>${icon('micoff')}</div><span class="tile-badge">Камера выключена</span></div><button class="empty-tile" data-action="invite"><span class="empty-plus">${icon('plus')}</span><span>Хорошие идеи любят компанию</span><small>Пригласите коллег по ссылке</small></button><div class="strip-note"><svg viewBox="0 0 115 58" aria-hidden="true"><path d="M108 4C45-6 33 38 8 43m10-15L7 43l20-1" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg><span>Соберите свой круг</span></div></div>
  </section>
  <section class="board-section" id="board-section">
    <div class="board-header"><div class="board-tabs"><button class="board-tab active" data-action="board">${icon('board')} Общая доска <span>01</span></button><button class="board-tab" data-action="video">${icon('video')} Видеовстреча</button></div><div class="board-actions"><span id="save-status">${icon('check')} Изменения сохраняются</span><button class="icon-button" data-action="export" title="Скачать доску" aria-label="Скачать доску">${icon('download')}</button><button class="icon-button" data-action="help" title="Подсказки" aria-label="Подсказки">${icon('more')}</button></div></div>
    <div class="board-viewport" id="viewport" tabindex="0" aria-label="Общая доска. Выберите инструмент и нажмите на доску.">
      <div class="board-world" id="world"><svg id="strokes" width="20000" height="20000" viewBox="-10000 -10000 20000 20000"></svg><div id="objects"></div><div id="cursors"></div></div>
      <div class="board-intro" id="board-intro"><span class="eyebrow">ПРОСТРАНСТВО ДЛЯ ВАШИХ ИДЕЙ</span><h2>Давайте создадим<br>что-то <em>вместе.</em><svg viewBox="0 0 220 16" aria-hidden="true"><path d="M3 11Q85 0 215 7M8 15Q90 5 195 11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></h2><p>Рисуйте, записывайте, делитесь.<br>Здесь каждый может добавить своё.</p></div>
      <div class="drawing-tools" role="toolbar" aria-label="Инструменты доски">${tool('cursor','Выбор и перемещение','V')}${tool('hand','Перемещение доски','H')}<div class="tool-separator"></div>${tool('pen','Карандаш','P')}${tool('text','Текст','T')}${tool('note','Стикер','N')}${tool('shape','Прямоугольник','R')}${tool('image','Изображение','I')}<div class="tool-separator"></div><button class="tool" data-action="undo" title="Отменить (Ctrl+Z)" aria-label="Отменить">${icon('undo')}</button><button class="tool" data-action="redo" title="Повторить (Ctrl+Shift+Z)" aria-label="Повторить">${icon('redo')}</button></div>
      <div class="color-toolbar" id="colors" hidden><button class="color active" style="--color:#334b37" data-color="#334b37" aria-label="Зелёный"></button><button class="color" style="--color:#b96f50" data-color="#b96f50" aria-label="Терракотовый"></button><button class="color" style="--color:#8874ad" data-color="#8874ad" aria-label="Сиреневый"></button><button class="color" style="--color:#4c83a1" data-color="#4c83a1" aria-label="Синий"></button><button class="color" style="--color:#252820" data-color="#252820" aria-label="Чёрный"></button></div>
      <div class="selection-toolbar" id="selection-toolbar" hidden><button data-action="edit-object">Изменить текст</button><button data-action="delete-object" aria-label="Удалить выбранный объект">${icon('trash')}</button></div>
      <div class="board-bottom"><div class="board-hint">${icon('cursor')}<span id="board-hint">Пробуйте — это ваша доска</span><kbd>?</kbd></div><div class="zoom-controls"><button data-action="zoom-out" aria-label="Уменьшить масштаб">${icon('minus')}</button><button data-action="reset-zoom" id="zoom-value" title="Вернуть масштаб">100%</button><button data-action="zoom-in" aria-label="Увеличить масштаб">${icon('plus')}</button><i></i><button data-action="fit" aria-label="Показать всю доску" title="Показать всю доску">${icon('fit')}</button></div></div>
      <div id="video-grid" hidden></div>
    </div>
  </section>
  <footer class="meeting-footer"><div class="footer-left"><span class="footer-logo">круг<span>●</span></span><span id="meeting-time">00:00</span><span class="footer-mode">Вместе — лучше</span></div><div class="call-controls"><button class="call-button off" data-action="mic" title="Включить микрофон" aria-label="Включить микрофон">${icon('micoff')}<span>Микрофон</span></button><button class="call-button off" data-action="camera" title="Включить камеру" aria-label="Включить камеру">${icon('videooff')}<span>Камера</span></button><i></i><button class="call-button" data-action="screen" title="Поделиться экраном" aria-label="Поделиться экраном">${icon('share')}<span>Экран</span></button><button class="call-button" data-action="hand" title="Поднять руку" aria-label="Поднять руку">${icon('hand')}<span>Рука</span></button><i></i><button class="call-button" data-action="people" title="Участники" aria-label="Участники">${icon('people')}<span>Участники</span></button><button class="call-button" data-action="chat" title="Чат встречи" aria-label="Чат встречи">${icon('chat')}<span>Чат</span></button></div><button class="leave-button" data-action="leave">${icon('leave')}<span>Выйти</span></button></footer>
</div>
<aside class="side-panel" id="side-panel" hidden><div class="panel-header"><h3 id="panel-title">Чат встречи</h3><button class="icon-button" data-action="close-panel" aria-label="Закрыть">${icon('close')}</button></div><div class="panel-content" id="panel-content"></div><form id="chat-form" hidden><input id="chat-input" placeholder="Сообщение вашему кругу…" maxlength="2000" autocomplete="off" aria-label="Сообщение"/><button type="submit" aria-label="Отправить сообщение">${icon('send')}</button></form></aside>
<dialog id="modal"><button class="modal-close icon-button" data-action="close-modal" aria-label="Закрыть">${icon('close')}</button><div id="modal-content"></div></dialog>
<input type="file" id="image-input" accept="image/png,image/jpeg,image/webp,image/gif" hidden />
<div class="toast" id="toast" role="status" hidden></div>
`;
