import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "КРУГ — место, где идеи становятся общими",
  description: "Видеовстречи и общая доска в одном пространстве. Рисуйте, делитесь идеями и создавайте вместе.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru">
      <body className="antialiased">{children}</body>
    </html>
  );
}
