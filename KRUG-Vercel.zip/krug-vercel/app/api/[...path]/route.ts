import { handle } from '../../server';
import { serve } from '../../../lib/postgres.mjs';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 30;
export const GET = (request: Request) => serve(request,handle);
export const POST = (request: Request) => serve(request,handle);
